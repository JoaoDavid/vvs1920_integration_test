DROP TABLE CUSTOMER if exists
DROP TABLE SALE if exists
DROP TABLE ADDRESS if exists
DROP TABLE SaleDelivery if exists